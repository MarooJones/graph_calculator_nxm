# 3D Graph Tool (Python • Dash + Plotly)

An interactive tool to visualize functions with domain/codomain:
- Scalar surfaces (height fields): **f: ℝ² → ℝ**, graph as *z = f(x, y)*.
- Parametric height-field surfaces: **z = z(u, v)** over the *(u, v)* domain (also **ℝ² → ℝ**).
- Parametric embedded surfaces: **F: ℝ² → ℝ³**, *(x(u, v), y(u, v), z(u, v))*.
- Parametric curves: **r: ℝ → ℝ³**, *(x(t), y(t), z(t))*.

## Install & run

```bash
python -m venv .venv
source .venv/bin/activate  # on Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:8050 in your browser.

## Syntax
- Use Python/SymPy syntax: `sin`, `cos`, `tan`, `exp`, `log`, `sqrt`, `abs`, `asin`, `acos`, `atan`, `sinh`, `cosh`, `tanh`, `floor`, `ceil`.
- Constants: `pi`, `E`.
- Exponentiation: `**`.
- Domain masks: any boolean expression in the domain variables (`x, y` or `u, v`) like `x**2 + y**2 <= 25`.

## Examples

### Scalar surface (ℝ² → ℝ)
- `f(x, y) = sin(sqrt(x**2 + y**2))` on `x ∈ [-6, 6], y ∈ [-6, 6]`
- Mask: `x**2 + y**2 <= 16`

### Parametric height-field (ℝ² → ℝ)
- `z(u, v) = cos(u) * sin(v)` with `u, v ∈ [-π, π]`

### Parametric embedded surface (ℝ² → ℝ³)
- Torus:
  - `x(u, v) = (2 + cos(v)) * cos(u)`
  - `y(u, v) = (2 + cos(v)) * sin(u)`
  - `z(u, v) = sin(v)`

### Parametric curve (ℝ → ℝ³)
- Lissajous-style knot:
  - `x(t) = cos(5*t) * (2 + cos(t))`
  - `y(t) = sin(5*t) * (2 + cos(t))`
  - `z(t) = sin(t)`

## Notes
- **Modes** map to the nature of the function:
  - Scalar surface: `f: ℝ² → ℝ`.
  - Parametric height-field: `z: ℝ² → ℝ` over `(u, v)` coordinates.
  - Parametric embedded surface: `F: ℝ² → ℝ³`.
  - Parametric curve: `r: ℝ → ℝ³`.
- Render style can be **Surface** or **Wireframe**.
- When a domain mask is active, surfaces are rendered via `Mesh3d` (triangulated point cloud) or scattered wire points.

## Roadmap
- Vector fields (ℝ² → ℝ² and ℝ³ → ℝ³) with quiver plots.
- Implicit surfaces (F(x,y,z)=0) via marching cubes.
- Better meshing for masked parametric surfaces (manifold triangulation).
- Multiple traces and color-by-scalar on parametric surfaces.
