from dash import Input, Output, State, no_update
import numpy as np
import plotly.graph_objects as go

from graph3d.core.parser import make_func_xy, make_mask_xy, make_func_uv, make_mask_uv, make_funcs_embed_uv, make_funcs_curve_t
from graph3d.core.samplers import grid_xy, grid_uv, lin_t
from graph3d.core.plotters import surface_from_xyz, wireframe_from_xyz, line_from_xyz

def _hide_all():
    return [{"display": "none"}] * 4

def _show(panel_id):
    # order: scalar_xy, param_height, param_embed, curve_t
    style = [{"display": "none"}] * 4
    idx = {"scalar_xy": 0, "param_height": 1, "param_embed": 2, "curve_t": 3}[panel_id]
    style[idx] = {}
    return style

def register_callbacks(app):
    @app.callback(
        Output("panel-scalar_xy", "style"),
        Output("panel-param_height", "style"),
        Output("panel-param_embed", "style"),
        Output("panel-curve_t", "style"),
        Input("mode", "value"),
    )
    def toggle_panels(mode):
        return _show(mode)

    @app.callback(
        Output("graph-3d", "figure"),
        Output("error", "children"),
        Input("mode", "value"),
        Input("scalar-fxy", "value"),
        Input("x-range", "value"),
        Input("y-range", "value"),
        Input("mask-xy", "value"),
        Input("param-z-uv", "value"),
        Input("u-range", "value"),
        Input("v-range", "value"),
        Input("mask-uv", "value"),
        Input("embed-x-uv", "value"),
        Input("embed-y-uv", "value"),
        Input("embed-z-uv", "value"),
        Input("embed-u-range", "value"),
        Input("embed-v-range", "value"),
        Input("mask-embed-uv", "value"),
        Input("curve-x-t", "value"),
        Input("curve-y-t", "value"),
        Input("curve-z-t", "value"),
        Input("t-range", "value"),
        Input("resolution", "value"),
        Input("render-style", "value"),
        prevent_initial_call=False
    )
    def update_figure(
        mode,
        fxy, x_range, y_range, mask_xy_expr,
        z_uv, u_range, v_range, mask_uv_expr,
        x_uv, y_uv, z_uv_embed, u_range_e, v_range_e, mask_e_expr,
        xt, yt, zt, t_range, resolution, render_style
    ):
        try:
            if mode == "scalar_xy":
                xs = np.linspace(x_range[0], x_range[1], int(resolution))
                ys = np.linspace(y_range[0], y_range[1], int(resolution))
                X, Y = grid_xy(xs, ys)
                f = make_func_xy(fxy)
                Z = f(X, Y)

                if (mask_xy_expr or "").strip():
                    m = make_mask_xy(mask_xy_expr)(X, Y)
                    X, Y, Z = X[m], Y[m], Z[m]
                    if render_style == "surface":
                        # Need to remesh masked surface; fallback to scatter trisurf via Delaunay (approx).
                        # Use Plotly Mesh3d for masked domains.
                        fig = go.Figure(go.Mesh3d(x=X.flatten(), y=Y.flatten(), z=Z.flatten(), opacity=0.95, intensity=Z.flatten(), colorscale="Viridis", showscale=True, alphahull=0))
                    else:
                        fig = wireframe_from_xyz(X, Y, Z, as_points=True)
                else:
                    if render_style == "surface":
                        fig = surface_from_xyz(X, Y, Z)
                    else:
                        fig = wireframe_from_xyz(X, Y, Z)

            elif mode == "param_height":
                us = np.linspace(u_range[0], u_range[1], int(resolution))
                vs = np.linspace(v_range[0], v_range[1], int(resolution))
                U, V = grid_uv(us, vs)
                fz = make_func_uv(z_uv)
                Z = fz(U, V)
                # Height-field lives over (u,v) plane -> treat x=u, y=v by default
                X, Y = U, V

                if (mask_uv_expr or "").strip():
                    m = make_mask_uv(mask_uv_expr)(U, V)
                    X, Y, Z = X[m], Y[m], Z[m]
                    if render_style == "surface":
                        fig = go.Figure(go.Mesh3d(x=X.flatten(), y=Y.flatten(), z=Z.flatten(), opacity=0.95, intensity=Z.flatten(), colorscale="Viridis", showscale=True, alphahull=0))
                    else:
                        fig = wireframe_from_xyz(X, Y, Z, as_points=True)
                else:
                    if render_style == "surface":
                        fig = surface_from_xyz(X, Y, Z, x=X, y=Y)
                    else:
                        fig = wireframe_from_xyz(X, Y, Z)

            elif mode == "param_embed":
                us = np.linspace(u_range_e[0], u_range_e[1], int(resolution))
                vs = np.linspace(v_range_e[0], v_range_e[1], int(resolution))
                U, V = grid_uv(us, vs)
                fx, fy, fz = make_funcs_embed_uv(x_uv, y_uv, z_uv_embed)
                X = fx(U, V)
                Y = fy(U, V)
                Z = fz(U, V)

                if (mask_e_expr or "").strip():
                    m = make_mask_uv(mask_e_expr)(U, V)
                    X, Y, Z = X[m], Y[m], Z[m]
                    if render_style == "surface":
                        fig = go.Figure(go.Mesh3d(x=X.flatten(), y=Y.flatten(), z=Z.flatten(), opacity=0.95, intensity=Z.flatten(), colorscale="Viridis", showscale=True, alphahull=0))
                    else:
                        fig = wireframe_from_xyz(X, Y, Z, as_points=True)
                else:
                    if render_style == "surface":
                        fig = surface_from_xyz(X, Y, Z, parametric=True)
                    else:
                        fig = wireframe_from_xyz(X, Y, Z)

            else:  # curve_t
                ts = lin_t(t_range[0], t_range[1], int(resolution))
                fx, fy, fz = make_funcs_curve_t(xt, yt, zt)
                X = fx(ts)
                Y = fy(ts)
                Z = fz(ts)
                fig = line_from_xyz(X, Y, Z)

            fig.update_layout(
                scene=dict(
                    xaxis_title="x",
                    yaxis_title="y",
                    zaxis_title="z",
                    aspectmode="data",
                ),
                margin=dict(l=0, r=0, t=30, b=0),
            )
            return fig, ""
        except Exception as e:
            return no_update, f"Error: {e}"
