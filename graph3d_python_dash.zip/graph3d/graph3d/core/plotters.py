import numpy as np
import plotly.graph_objects as go

def surface_from_xyz(X, Y, Z, x=None, y=None, parametric=False):
    # Plotly Surface expects 2D arrays; ensure shapes match
    if x is None: x = X
    if y is None: y = Y
    surf = go.Surface(x=x, y=y, z=Z, colorscale="Viridis", showscale=True, opacity=0.96)
    fig = go.Figure(surf)
    return fig

def _wireframe_lines(X, Y, Z):
    lines = []
    # rows (constant y / v)
    for i in range(X.shape[0]):
        lines.append(go.Scatter3d(x=X[i,:], y=Y[i,:], z=Z[i,:], mode="lines", line=dict(width=1)))
    # cols (constant x / u)
    for j in range(X.shape[1]):
        lines.append(go.Scatter3d(x=X[:,j], y=Y[:,j], z=Z[:,j], mode="lines", line=dict(width=1)))
    return lines

def wireframe_from_xyz(X, Y, Z, as_points=False):
    if as_points:
        return go.Figure(go.Scatter3d(x=X.flatten(), y=Y.flatten(), z=Z.flatten(), mode="markers", marker=dict(size=2)))
    if X.ndim == 1 or Y.ndim == 1 or Z.ndim == 1:
        # Try to infer grid shape (fallback to points)
        return go.Figure(go.Scatter3d(x=X.flatten(), y=Y.flatten(), z=Z.flatten(), mode="markers", marker=dict(size=2)))
    lines = _wireframe_lines(X, Y, Z)
    fig = go.Figure(lines)
    return fig

def line_from_xyz(X, Y, Z):
    return go.Figure(go.Scatter3d(x=X, y=Y, z=Z, mode="lines"))
